python masshare.py -d 0ADVmSrexpJ_DUk9PVA
python masshare.py -d 0AGYDNtIEYTh3Uk9PVA