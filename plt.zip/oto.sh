index=0
baglanti="SPPLOT"
configbag="plotgonder"
while :
do
sayi=($(ls -lR /root/disk1/data/*.plot | wc -l))

if [[ $sayi -gt 0 ]]; then  
   index=$(($index + 1))
   if [[ $index -gt 10 ]]; then
      index=1
   fi
   echo "Txt Kop $index1"
   rclone backend set $baglanti: -o service_account_file="/root/$configbag/accounts/$index.json"
   echo "backend degisti"
   rclone move /root/disk1/data/  $baglanti: --ignore-existing --buffer-size 64M --drive-chunk-size 64M --checkers 4 --tpslimit 4 --transfers 2 --fast-list --progress --include "/*.plot" -P;
   echo "bitti"
   sleep 5
fi
sleep 1
done
